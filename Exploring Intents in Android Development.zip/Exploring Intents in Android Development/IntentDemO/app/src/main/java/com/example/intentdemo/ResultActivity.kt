package com.yourpackagename

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class ResultActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_result)

        findViewById<Button>(R.id.btnReturnResult).setOnClickListener {
            val resultIntent = Intent()
            resultIntent.putExtra("result_data", "This is the result from ResultActivity")
            setResult(Activity.RESULT_OK, resultIntent)
            finish()
        }
    }
}
