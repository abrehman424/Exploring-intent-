package com.yourpackagename

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var editText: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        editText = findViewById(R.id.editText)

        findViewById<Button>(R.id.btnGoToSecond).setOnClickListener {
            val inputText = editText.text.toString()
            val intent = Intent(this, SecondActivity::class.java)
            intent.putExtra("user_input", inputText)
            startActivity(intent)
        }

        findViewById<Button>(R.id.btnOpenWeb).setOnClickListener {
            val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.example.com"))
            startActivity(webIntent)
        }

        findViewById<Button>(R.id.btnShareText).setOnClickListener {
            val shareIntent = Intent().apply {
                action = Intent.ACTION_SEND
                putExtra(Intent.EXTRA_TEXT, "Check out this amazing app!")
                type = "text/plain"
            }
            startActivity(Intent.createChooser(shareIntent, "Share via"))
        }
    }
}
